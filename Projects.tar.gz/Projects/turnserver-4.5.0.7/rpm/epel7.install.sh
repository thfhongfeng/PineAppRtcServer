#!/bin/bash

# Epel installation script

sudo yum -y install epel-release



